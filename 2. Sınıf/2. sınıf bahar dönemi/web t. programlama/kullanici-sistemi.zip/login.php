<?php
include "config.php";
?>

<form action="login_do.php" method="POST">
Kullanıcı Adı: <input type="text" name="uname"><br>
Şifre: <input type="password" name="upass"><br>
<input type="submit" value="Giriş Yap!">
</form>
