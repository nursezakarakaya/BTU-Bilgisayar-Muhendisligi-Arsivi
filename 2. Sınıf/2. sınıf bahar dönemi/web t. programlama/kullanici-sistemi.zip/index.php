<?php


include "config.php";


?>
<!DOCTYPE html>
<html>
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
    
    
    <!--
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    -->

    <style>
    .jumbotron {
        padding: 2rem 1rem;
        margin-bottom: 2rem;
        background-color: #e9ecef;
        border-radius: .3rem;
    }

    .bg-info {
        background-color: #bef0fe!important;
        font-size: 26px;
    }
    </style>

</head>
<body>


<div class="container">

    <!--NAVBAR-->
    <?php

    //giriş yapılmışsa
    // if (isset($_COOKIE["id"]) && $_COOKIE["id"] > 0)
    if ($theuser)
    {
    ?>
        <a onclick="ProfiliDuzenle()">Profili Düzenle (@<?php echo $theuser["username"]; ?>)</a>
        |
        <a href="logout.php">Çıkış Yap (#<?php echo $_SESSION["id"]; ?>)</a>
    <?php
    }
    else
    {
    ?>
        <a href="signup.php">Kayıt Ol</a>
        |
        <a href="login.php">Giriş Yap</a>
    <?php
    }
    ?>


    <hr>

    <script src="kod.js"></script>


    <?php /* CONTENT */ ?>
    <div id="content">

        <div class="jumbotron">
        <h1>İçerik Başlığı</h1>
        Standart içerik
        </div>


        <div class="row">

        <div class="col-2 bg-info">
            Menü<br>Menü<br>Menü<br>Menü<br>Menü<br>Menü<br>Menü<br>Menü<br>Menü<br>Menü<br>Menü<br>Menü<br>Menü<br>
        </div>

        <div class="col-10">
            <div class="row">

                <div class="col bg-secondary">
                İçerik 1
                </div>

                <div class="col bg-danger">
                <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sint maiores quam, a praesentium dicta architecto porro vel tenetur, possimus animi blanditiis deserunt explicabo beatae ipsa perferendis laborum id pariatur. Eum.</p>
                <p>Totam, accusantium non. Corrupti, provident. Totam iste rerum quos facilis similique ea accusamus assumenda explicabo voluptatum quia debitis aspernatur commodi ducimus asperiores, reprehenderit maxime numquam vel, eligendi vitae. Doloremque, tempora!</p>
                <p>Aliquam amet rem tenetur eum adipisci repellendus reiciendis, ducimus deleniti quod tempore magnam consequuntur distinctio possimus neque aperiam aliquid perferendis? Error nam, rem voluptatem voluptatibus tempora quos impedit at ducimus.</p>
                <p>Labore, culpa reiciendis atque aperiam nisi nobis corrupti veritatis illo dolores officia omnis sit tenetur totam ad. Blanditiis ipsam, est laboriosam unde earum provident asperiores delectus! Voluptatem quisquam doloremque earum?</p>
                </div>
            </div>


            <div class="row">
                <div class="col-md-9 col-3 bg-success">
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequatur totam quis maiores consectetur, eius laboriosam aliquam maxime alias optio ullam dignissimos culpa veritatis earum, iusto ut, dolorem debitis quos repellat?</p>
                </div>

                <div class="col-md-3 col-9 bg-warning">
                Lorem ipsum dolor, sit amet consectetur adipisicing elit. Laborum in facere optio facilis ex, dolores maxime, vero dignissimos modi tenetur eos corrupti rerum iusto quo unde incidunt iste debitis repellat?
                Quasi accusantium odit perspiciatis, omnis quos consequuntur officia illo repellendus ea quas quia quod doloribus illum nemo dicta magnam commodi laborum et esse debitis similique sunt qui! Quidem, corrupti voluptatem!
                </div>

            </div>
        </div>

        </div>

    </div>


</div>
</body>
</html>