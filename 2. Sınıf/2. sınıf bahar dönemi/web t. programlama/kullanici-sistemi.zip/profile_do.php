<?php

include "config.php";


$phone = $_POST["phone"];


$result = $mysqli -> query("UPDATE users SET telnumber=".$phone." WHERE id=".$theuser["id"]);

if (!$result)
{
    echo "Hata meydana geldi!";
    echo $mysqli -> error;
}
else
{
    echo "Başarılı!";
}
?>