<?php

include "config.php";

?>



<form action="signup_do.php" method="POST">
Kullanıcı Adı: <input type="text" name="uname"><br>
Şifre: <input type="password" name="upass"><br>
Telefon: <input type="number" name="utel"><br>
Doğum tarihiniz: <input type="date" name="ubdate"><br>

<input type="submit" value="Kayıt Ol!">
</form>