<?php
require_once "config.php";

// setcookie("admingirisyapti", "0", time() - 60);
$_SESSION["admingirisyapti"] = "0";
// unset()
session_destroy();

session_start();
session_regenerate_id();

