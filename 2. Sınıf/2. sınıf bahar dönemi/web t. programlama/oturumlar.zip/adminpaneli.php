<?php

require_once "config.php";

// if(isset($_COOKIE["admingirisyapti"]) && $_COOKIE["admingirisyapti"]=="1")
// {
// kullanıcıyı kabul et
// }


// if(!isset($_COOKIE["admingirisyapti"]) || $_COOKIE["admingirisyapti"]!="1")
// {
//     // kullanıcıyı reddet
//     echo "Giriş yapamazsınız!";
//     exit();
// }

if(!isset($_SESSION["admingirisyapti"]) || $_SESSION["admingirisyapti"]!="1")
{
    // kullanıcıyı reddet
    echo "Giriş yapamazsınız!";
    exit();
}

echo "Kontroller... Çok özel bilgiler...";


echo "<hr><a href='cikisyap.php'>Çıkış Yap</a>";

