<?php

require_once "config.php";


if (isset($_POST["username"]))
{
    $form_username = $_POST["username"];
    $form_password = $_POST["password"];

    
    $form_password_hash = hash("sha256", $form_password);

    $q = mysqli_query($db, "SELECT * FROM users WHERE `username`='$form_username' AND `password`='$form_password_hash'");
    $num = mysqli_num_rows($q);

    if($num == 0)
    {
        echo "Böyle bir kullanıcı bulunamadı! Şifrenizi kontrol ediniz.";
        exit;
    }
    else if($num == 1)
    {
        $user = mysqli_fetch_assoc($q);
        echo "Giriş başarılı! Hoş geldiniz, Sn. ".$user["name"]."...";
        exit;
    }

}
else
{

?>

<form action="login.php" method="POST">
    Kullanıcı adı: <input type="text" name="username"><br>
    Şifre: <input type="password" name="password"><br>

    <button type="submit">Giriş Yap!</button>
<form>

<?php
}
?>