<?php

require_once "config.php";

if (isset($_POST["username"]))
{
    $form_username = $_POST["username"];
    $form_password = $_POST["password"];
    $form_email = $_POST["email"];

    $passlen = strlen($form_password);
    if($passlen < 6 || $passlen > 15)
    {
        echo "Şifre en az 6, en fazla 15 karakterden oluşmalıdır!";
        exit;
    }

    //eposta - regex

    $form_password_hash = hash("sha256", $form_password);


    $rt = mysqli_query($db, "INSERT INTO `users` (`username`, `password`, `email`) VALUES ('".$form_username."', '".$form_password_hash."', '".$form_email."')");

    
    // if(!$rt)
    // {
    //     echo "Bir hata meydana geldi!";
    // }

    if(mysqli_errno($db) != 0)
    {
        echo "Bir hata meydana geldi!";
        exit;
    }

    echo "Kullanıcı kaydınız başarılı!<br>";
    echo "Giriş yapmak için <a href='login.php'>tıklayınız</a>";


}
else
{
?>

<form action="signup.php" method="POST">
    Kullanıcı adı: <input type="text" name="username"><br>
    Şifre: <input type="password" name="password"><br>
    Eposta: <input type="email" name="email"><br>

    <button type="submit">Kayıt Ol!</button>
<form>

<?php
}
?>